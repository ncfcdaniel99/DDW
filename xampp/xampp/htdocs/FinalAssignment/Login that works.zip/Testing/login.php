    <title>PHP Script to View Page Only After Login | PlanetGhost.com</title>
    <center>
    <h3>PHP Script to View Page Only After Login(Demo)</h3>
    <a href="index.php">HOME</a> | <a href="locked.php">Locked Page</a> |  
    <?php
    if(!isset($_SESSION['auth']))
    {
    ?>
    <b><a href="login.php">Login</a> </b>
    <?php
    }
    else
    {
    ?>
     <b><a href="logout.php">Logout</a></b>
     <?php
     }
     ?>
    <?php
    session_start() ;
    if(isset($_SESSION['success']))
    {
    ?>
    <div class="success">
    <?php echo $_SESSION['success'] ; ?>
    </div>
    <?php
    unset($_SESSION['success']) ;
    }
    if(isset($_SESSION['failure']))
    {
    ?>
    <div class="failure">
    <?php echo $_SESSION['failure'] ;?>
    </div>
    <?php
    unset($_SESSION['failure']) ;
    }
    ?>
     <h2>Login Page</h2>
    <div class="form">
        <form action="loggingin.php" method="post">
		<div class="input-group">
            <label for="email">email</label>
            <input type="text" id="email" name="email"><br>
			</div>
		<div class="input-group">
            <label for="password">Password</label>
            <input type="text" id="password" name="password"><br>
						</div>
		<div class="input-group">

  <input type="checkbox" name="savecookie"> I want to store a cookie<br>
  <input type="submit" value="Submit">

        </div>
		</form>
    </div>
    </center>
    <style>
    .form{
        border: 1px solid #D3D3D3;
        text-align: center;
        width: 200px;
    }
    .success{
        background: none repeat scroll 0 0 #90EE90;
        width: 200px;
    	border: 1px solid darkgreen ;
    }
    .failure{
    background: none repeat scroll 0 0 #E56255 ;
     width: 200px;
    	border: 1px solid red ;
    }
    </style>