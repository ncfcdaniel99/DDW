    <?php
    session_start() ;
    if(!isset($_SESSION['auth']))
    {
    header("Location:login.php") ;
    }
    ?>
    <title>PHP Script to View Page Only After Login | PlanetGhost.com</title>
    <center>
    <h3>PHP Script to View Page Only After Login(Demo)</h3>
    <?php
    if(isset($_SESSION['success']))
    {
    ?>
    <div class="success">
    <?php echo $_SESSION['success'] ; ?>
    </div>
    <?php
    unset($_SESSION['success']) ;
    }
    if(isset($_SESSION['failure']))
    {
    ?>
    <div class="failure">
    <?php echo $_SESSION['failure'] ;?>
    </div>
    <?php
    unset($_SESSION['failure']) ;
    }
    ?>
    <a href="index.php">HOME</a> | <b><a href="locked.php">Locked Page</a></b> |  
    <?php
    if(!isset($_SESSION['auth']))
    {
    ?>
    <a href="login.php">Login</a> 
    <?php
    }
    else
    {
    ?>
     <a href="logout.php">Logout</a>
     <?php
     }
     ?>
     <h2>Locked Page</h2>
    <p>You can view this page and content as you are logged in.<br>
    Non-Logged in users will be redirected to login page when they come in this page</p>
    </center>