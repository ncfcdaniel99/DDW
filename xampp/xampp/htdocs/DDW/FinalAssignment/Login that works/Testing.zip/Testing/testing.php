<!DOCTYPE html>
<html lang="en">
<head>
  <title>Automobile Trader</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="main.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm navbar-dark fluid">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="">
    <img src="logo.png" alt="logo" style="width:80px;">
  </a>
  
  <div class >
 <h1> Automobile Trader </h1>
  </div>
  <!-- Links -->
  
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="testing.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="searchCars.php">Search Cars</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">About</a>
    </li>
	
	    <li class="nav-item">
      <a class="nav-link" href="Admin/adminlocked.php">Admin</a>
    </li>
	

  </ul>
</nav>

<div class="cardeals" id="cardeals">
  <div class="container">
  <h1>Latest Car Deals</h1>
    <div class="row">
      <?php 
      require 'config.php';
      $sqlQuery=$pdo->query('SELECT * FROM cars  ORDER BY RAND() DESC LIMIT 3');
      while($row = $sqlQuery->fetch())
      {
        ?>
       <div class="card" >
        <div class="card">
          <div class="card-img-top">
            <img class ="card-img-top" src="<?php echo 'pictures/'.$row['picture'];?>" >  
          </div >
          <div class="card-body">
            <h4 class="card-title"><?php echo $row['make']." ".$row['model']; ?><span class="badge  badge-info">New</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="badge  badge-success"><?php echo '£'.$row['price']; ?></span>  </h4>
            
            <p class="card-text"><?php echo $row['colour'].' | '.$row['description'].' | '.$row['miles'].' | '.$row['town']; ?></p>
          </div>
          <div class="card-footer">
            <a href='<?php echo "viewCarDetails.php?carIndex=".$row['carIndex'].""; ?>' class="btn btn-primary stretched-link">View</a>
          </div>  
        </div>
      </div>
      <?php } ?> 
      
    </div> 
  </div>  
</div>

<?php




while($row = $sqlQuery->fetch())

{
 


    echo "<align = center><img class =CarImage src='pictures/".$row['picture']."'";

    ?>
    <div class="carinfo">    
      <?php


	echo "<div class= carinfo><align = center>Make: ".$row['make']."<br>";

	echo "<align = center>Model: ".$row['model']."<br>";

	echo "<align = center>Colour: ".$row['colour']."<br>";

	echo "<align = center>Region: ".$row['region']."<br>";

	echo "<align = center>Town: ".$row['town']."<br>";


  echo "<align = center>Reg: ".$row['Reg']."<br><br>" ;
  echo " <div class=button onclick=location.href='locked.php?carIndex=".$row['carIndex']."'>Buy a car</div>";



	echo"";


echo "<TR>";
  }

?>




</body>
</html>
