 <?php
    session_start() ;
	    if(!isset($_SESSION['auth']))
    {
    header("Location:adminlogin.php") ;
    }
    ?><head>
  <title>Automobile Trader</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../main.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-sm navbar-dark fluid">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="">
    <img src="logo.png" alt="logo" style="width:80px;">
  </a>
  
  <div class >
 <h1> Automobile Trader </h1>
  </div>
  <!-- Links -->
  
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="carResult.php">Search Cars</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">About</a>
    </li>
	
    <li class="nav-item">
	 <?php
    if(!isset($_SESSION['auth']))
    {
    ?>
    <a class="nav-link" href="adminlogin.php">Admin Login</a> 
    <?php
    }
    else
    {
    ?>
    <a class="nav-link" href="adminlogout.php">Admin Logout</a>
    <?php
     }
    ?>
    <?php
    if(isset($_SESSION['success']))
    {
    ?>
    <div class="success">

    </div>
    <?php
    unset($_SESSION['success']) ;
    }
    if(isset($_SESSION['failure']))
    {
    ?>
    <div class="failure">
    <?php echo $_SESSION['failure'] ;?>
    </div>
    <?php
    unset($_SESSION['failure']) ;
    }
    ?>
</li>
  </ul>
</nav><?php
require 'config.php';

$sql = "UPDATE cars SET make = :make, model = :model, 
            Reg = :Reg,  
            colour = :colour, 
            miles = :miles,  
            price = :price,  
            dealer = :dealer,
			town = :town, 
            telephone = :telephone,  
            description = :description,  
            region = :region,  
            picture = :picture,
			            purchased = :purchased

            WHERE carIndex = :carIndex"
			;
			
$sqlQuery = $pdo->prepare($sql);                                  
$sqlQuery->bindParam(':make', $_POST['make']);       
$sqlQuery->bindParam(':model', $_POST['model']);    
$sqlQuery->bindParam(':Reg', $_POST['Reg']);
$sqlQuery->bindParam(':colour', $_POST['colour']); 
$sqlQuery->bindParam(':miles', $_POST['miles']);   
$sqlQuery->bindParam(':price', $_POST['price']);   
$sqlQuery->bindParam(':dealer', $_POST['dealer']); 
$sqlQuery->bindParam(':town', $_POST['town']); 
$sqlQuery->bindParam(':telephone', $_POST['telephone']); 
$sqlQuery->bindParam(':description', $_POST['description']);   
$sqlQuery->bindParam(':region', $_POST['region']);   
$sqlQuery->bindParam(':picture', $_POST['picture']); 
$sqlQuery->bindParam(':purchased', $_POST['purchased']); 
$sqlQuery->bindParam(':carIndex',$carIndex); 
$sqlQuery->execute(); 

echo "<h1  align=center>Car updated</h1>";
   header('Refresh: 5; URL=adminlocked.php');
?>
