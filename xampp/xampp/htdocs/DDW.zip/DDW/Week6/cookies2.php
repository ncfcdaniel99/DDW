<?php

echo "Username = ".$_COOKIE['username'];
echo "<br>";
echo "Password = ".$_COOKIE['password'];
?>