<?php

setcookie("username", "DDicker", time()+3600);
setcookie("password", "1234", time()+3600);

echo"Cookies created"
?>