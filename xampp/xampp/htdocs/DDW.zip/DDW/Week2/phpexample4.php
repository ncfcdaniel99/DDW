<?php

	$number = 2;
	$i =1;
	for ($i==1; $i<13;$i++)
	{
		echo ($number * $i)."<br>";
	}
	
	
?>