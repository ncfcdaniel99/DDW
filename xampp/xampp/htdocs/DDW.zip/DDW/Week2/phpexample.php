<?php

	echo "This is processed by the server";
	print "<h1>This is also processed by the server</h1>";
	
	echo "<p> <b> <font color=green> <font size = 12> This is processed by the server </b></p>" ;

	echo "
<table border=1>

  <tr >
    <td>HTML</td>
    <td>PHP</td>
  </tr>
  <tr>
    <td>Used to create Websites, code runs on the clients computer and is interpreted by the web browser</td>
    <td>Used to access Databases and to interact with the user, code runs on the web server and is displayed on the clients web browser</td>
  </tr>

</table>
";

	
?>