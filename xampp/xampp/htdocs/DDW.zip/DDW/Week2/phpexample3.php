<?php

	$username = "DD531";
	$password = 12345;

if($username == "DD531" && $password == 12345)
	
	{
		echo "This is correct";
		}
	
	else 
	{
		echo"You are wrong";
	}
	
?>