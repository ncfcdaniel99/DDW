<?php
$quantity = $_POST['quantity'];
$book = $_POST['book'];

	echo "<p> <b> <font color=red> <font size = 7>You ordered ". $quantity . " " . $book . " books" . ".<br />";
	echo "Thank you for ordering from BooksRUS </b></p>";

?>
