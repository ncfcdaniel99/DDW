<?php

	$username = "DD531";
	$password = 12345;
	$number1 = 12;
	$number2 = 33;

	echo "Your username is: ".$username. "<br>";
	
	echo "The total is:".($number1+$number2);
	
?>